package com.it355pz2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainTests {

	@Test
	void contextLoads() {
	}

}
