package com.it355pz2.services;


import com.it355pz2.dto.SkillResponse;

import java.util.List;

public interface SkillService {
    List<SkillResponse> getSkills();

}
