package com.it355pz2.dto;

import com.it355pz2.entity.enums.ApplicationStatus;
import lombok.Data;

@Data
public class ApplicationDto {
    private String description;
}
